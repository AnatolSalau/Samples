#JavaFX Settings UI Inspiration
Another UI inspiration for JavaFX.

![alt text](https://github.com/k33ptoo/Settings/blob/master/images/img.PNG)


Catch me outside.
* https://www.facebook.com/keeptoo.ui.ux/
* https://www.youtube.com/KeepToo
* https://t.me/byte2bits
