# Sample JavaFX Dashboards
![](sc2.PNG) 
![](sc1.png) 

This project is purely JavaFX - it gives you a basis of what to do regarding your projects, **Note:** it is not a fully fledged system. 
